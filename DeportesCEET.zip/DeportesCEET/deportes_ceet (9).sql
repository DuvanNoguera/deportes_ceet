-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 27-09-2022 a las 22:56:08
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `deportes_ceet`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aprendiz`
--

CREATE TABLE `aprendiz` (
  `identificación` int(100) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `contraseña` varchar(100) NOT NULL,
  `rol` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `aprendiz`
--

INSERT INTO `aprendiz` (`identificación`, `nombre`, `apellido`, `correo`, `contraseña`, `rol`) VALUES
(51, 'Sergio Andres', 'Gonzales Cruz', 'sagonzalez89@misena.edu.co', 'sagonzalez89', 'Admin'),
(52, 'Duvan Adey', 'Noguera Bocachica', 'danoguera00@misena.edu.co', 'danoguera00', 'Admin'),
(53, 'Wlrmer Ivan', 'Rodríguez Páez', 'wirodriguez7@misena.edu.co', 'wirodriguez7', 'Admin'),
(54, 'Erick Andrés Felipe', 'Quiñones Fonseca', 'eaquiones7@misena.edu.co', 'eaquiones7', 'Admin'),
(55, 'Juan Daniel', 'Hernández Moreno', 'jdhernandez0097@misena.edu.co', 'jdhernandez0097', 'Admin'),
(56, 'roberto', 'gomez', '1@11111', '1', 'Usuario'),
(57, '1', '1', 'juanda9791@gmail.com', '1', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ciudad`
--

CREATE TABLE `ciudad` (
  `ID_Ciudad` int(11) NOT NULL,
  `Nombre_Ciudad` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ciudad`
--

INSERT INTO `ciudad` (`ID_Ciudad`, `Nombre_Ciudad`) VALUES
(1, 'Bogota'),
(2, 'Cali'),
(3, 'Medellin');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `deportes`
--

CREATE TABLE `deportes` (
  `ID_Deportes` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Inscripcion` varchar(100) NOT NULL,
  `Fecha_de_ingreso` date NOT NULL,
  `ID_Aprendices` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `deportes`
--

INSERT INTO `deportes` (`ID_Deportes`, `Nombre`, `Inscripcion`, `Fecha_de_ingreso`, `ID_Aprendices`) VALUES
(1, 'Futbol', '1', '2022-05-10', 1),
(2, 'Ping Pong', '1', '2022-05-10', 2),
(3, 'Baloncesto', '1', '2022-05-10', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticias`
--

CREATE TABLE `noticias` (
  `ID_Noticias` int(11) NOT NULL,
  `Invitacion` int(11) NOT NULL,
  `Campeonato` varchar(100) NOT NULL,
  `Inscripcion` int(11) NOT NULL,
  `ID_Deportes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `noticias`
--

INSERT INTO `noticias` (`ID_Noticias`, `Invitacion`, `Campeonato`, `Inscripcion`, `ID_Deportes`) VALUES
(1, 1, 'Futbol', 1, 1),
(2, 1, 'Ping Pong', 1, 2),
(3, 1, 'Baloncesto', 1, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sede`
--

CREATE TABLE `sede` (
  `ID_Sede` int(11) NOT NULL,
  `Telefno` int(11) NOT NULL,
  `ID_Ciudad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `sede`
--

INSERT INTO `sede` (`ID_Sede`, `Telefno`, `ID_Ciudad`) VALUES
(1, 12121212, 1),
(2, 23232323, 2),
(3, 45454545, 3);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `aprendiz`
--
ALTER TABLE `aprendiz`
  ADD PRIMARY KEY (`identificación`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `aprendiz`
--
ALTER TABLE `aprendiz`
  MODIFY `identificación` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
