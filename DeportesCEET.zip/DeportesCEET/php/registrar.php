<?php
//Para registrar
include('conexion.php');

$nombre = $_POST["nombre"];
$apellido 	= $_POST["apellido"];
$correo = $_POST["correo"];
$contraseña = $_POST["contraseña"];
$rol 	= $_POST["rol"];

$queryusuario 	= mysqli_query($conn,"SELECT * FROM aprendiz WHERE correo = '$correo'");
$nr 			= mysqli_num_rows($queryusuario); 

if ($nr == 0)
{
	$queryregistrar = "INSERT INTO aprendiz(nombre,apellido,correo,contraseña,rol) values ('$nombre','$apellido','$correo','$contraseña','$rol')";
	

if(mysqli_query($conn,$queryregistrar))
{
	echo "<script> alert('Usuario registrado: $correo');window.location= '../index.html' </script>";
}
else 
{
	echo "Error: " .$queryregistrar."<br>".mysql_error($conn);
}

}
else
{
		echo "<script> alert('No puedes registrar este correo: $correo');window.location= '../index.html' </script>";
}

?>


