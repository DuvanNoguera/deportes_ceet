<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
     <title>VaidrollTeamLogin7</title>
     <link rel="stylesheet" href="vaidroll.css">	
</head>
<table>
<th colspan="2">Bienvenido admin</th><th><a href="../index.html">Regresar</a></th>
<tr><th colspan="3"><h1>Listado de usuarios</h1></th></tr>
<tr>
<th>nombre</th>
<th>apellido</th>
<th>correo</th>
<th>Contraseña</th>
<th>Rol</th>

</tr>

<?php

 include('conexion.php');

$sql="select * from aprendiz";
$resultado=mysqli_query($conn,$sql);

while($mostrar=mysqli_fetch_array($resultado))

{
?>

<tr>
    <td><?php echo $mostrar['nombre'] ?></td>
	<td><?php echo $mostrar['apellido'] ?></td>
	<td><?php echo $mostrar['correo'] ?></td>
	<td><?php echo $mostrar['contraseña'] ?></td>
	<td><?php echo $mostrar['rol'] ?></td>
</tr>

<?php
}
?>

</table>

</body>
</html>
