<?php

include('conexion.php');

$correo = $_POST["correo"];
$contraseña = $_POST["contraseña"];
$rol 	= $_POST["rol"];


//Para iniciar sesión

$queryusuario = mysqli_query($conn,"SELECT * FROM aprendiz WHERE correo ='$correo' and contraseña = '$contraseña'and rol = '$rol'");
$nr 		= mysqli_num_rows($queryusuario);   
   
if ($nr == 1 )  
   { 
       if($rol=="Usuario")
           {	
            echo "<script> alert('Bienvenido a Deportes CEET:');window.location= 'https://depoceet.000webhostapp.com/deportes/index.html' </script>";
            
           }
       else if ($rol=="Admin")
           {
            echo "<script> alert('Bienvenido Admin a Deportes CEET');window.location= 'pag_admin.php' </script>";   
            
           }
   }
else
   {
   echo "<script> alert('Usuario, contraseña o rol incorrecto.');window.location= '../index.html' </script>";
   }

?>


