<?php
include('conexion.php');

$correo = $_POST['txtcorreo'];

$queryusuario 	= mysqli_query($conn,"SELECT * FROM aprendiz WHERE correo = '$correo'");
$nr 			= mysqli_num_rows($queryusuario); 
if ($nr == 1)
{
$mostrar		= mysqli_fetch_array($queryusuario); 
$enviarpass 	= $mostrar['contraseña'];

$paracorreo 		= $correo;
$titulo				= "Recuperar Password";
$mensaje			= "Tu password es: ".$enviarpass;
$tucorreo			= "From: ceetdeportes@gmail.com";

if(mail($paracorreo,$titulo,$mensaje,$tucorreo))
{
	echo "<script> alert('Contraseña enviado');window.location= '../vista/form-message.html' </script>";
}else
{
	echo "<script> alert('Error');window.location= '../vista/password-reset.html' </script>";
}
}
else
{
	echo "<script> alert('Este correo no existe');window.location= '../vista/password-reset.html' </script>";
}

?>

