Swal.fire({
    icon: 'error',
    title: 'Oops...',
    text: 'Los datos no corresponden!',
    footer: '<a href="">Olvido su contraseña?</a>'
  })
  