
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Latform - Login and Register Form Templates</title>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../../dist/vendor/bootstrap-4.5.3/css/bootstrap.min.css" type="text/css">
    <!-- Material design icons -->
    <link rel="stylesheet" href="../../dist/icons/material-design-icons/css/mdi.min.css" type="text/css">
    <!-- Google font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300&display=swap" rel="stylesheet">
    <!-- Latform styles -->
    <link rel="stylesheet" href="../../dist/css/latform-style-6.min.css" type="text/css">
</head>
<body>
<div class="form-shape-wrapper">
    <div class="form-shape">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 3000 185.4">
            <path fill="red" d="M3000,0v185.4H0V0c496.4,115.6,996.4,173.4,1500,173.4S2503.6,115.6,3000,0z"></path>
        </svg>
    </div>
</div>
<div class="form-wrapper">
    <div class="container">
        <div class="card">
            <div class="row no-gutters">
                <div class="col d-none d-lg-flex" style="background: url(../../dist/images/cover2.jpg)">
                    <div class="logo">
                        <img src="../../dist/images/logo-colorful.png" alt="logo">
                    </div>
                    <div>
                        <h3 class="font-weight-bold">Hacer una acción diferente</h3>
                        <p class="lead my-5">¿Vas a hacer una acción diferente?</p>
                        <div class="text-center">
                            Ahora puedes <a class="btn btn-outline-primary btn-sm" href="sign-in.html">Iniciar sesión</a> o
                            <a class="btn btn-outline-primary btn-sm" href="sign-up.html">Crear una cuenta</a>.
                        </div>
                    </div>
                    <ul class="list-inline">
                        <li class="list-inline-item">
                            <a href="#">Politica y privacidad</a>
                        </li>
                        <li class="list-inline-item">
                            <a href="#">Terminos y condiciones</a>
                        </li>
                    </ul>
                </div>
                <div class="col">
                    <div class="row h-100 align-items-center">
                        <div class="col-md-10 offset-md-1">
                            <div class="logo d-block d-lg-none text-center text-lg-left">
                                <img src="../../dist/images/logo-colorful.png" alt="logo">
                            </div>
                            <div class="my-5 text-center text-lg-left">
                                <h3 class="font-weight-bold">Restablecer contraseña</h3>
                                <p class="text-muted">Escriba y envíe la dirección de correo electrónico para restablecer su contraseña.     </p>
                            </div>
                            <form>
                                <div class="form-group">
                                    <div class="form-icon-wrapper">
                                        <input type="email" class="form-control" id="email" placeholder="Ingrese su correo*"
                                               autofocus
                                               required>
                                        <i class="form-icon-left mdi mdi-email"></i>
                                    </div>
                                </div>
                                <button class="btn btn-primary btn-block mb-4">Enviar</button>
                            </form>
                            <p class="text-center d-block d-lg-none mt-3 mt-lg-0">
                                You can now <a href="sign-in.html">sign in</a> or <a href="sign-up.html">create an
                                account</a>.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Jquery -->
<script src="../../dist/vendor/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="../../dist/vendor/bootstrap-4.5.3/js/bootstrap.min.js"></script>
<!-- Latform scripts -->
<script src="../../dist/js/latform.min.js"></script>
</body>
</html>
