<?php

    $usuario = "root"; 
    $password = ""; 
    $servidor = "localhost"; 
    $basededatos ="prueba"; 


$conexion = mysqli_connect  ($servidor,$usuario,"") or die ("Error con el servidor de la Base de datos"); 


$db = mysqli_select_db($conexion, $basededatos) or die ("Error conexion al conectarse a la Base de datos");


    $nombre=$_POST['nombre']; 
    $apellido=$_POST['apellido']; 
    $correo=$_POST['correo']; 
    $contraseña=$_POST['contraseña']; 
   

    $contraseña = password_hash($contraseña,PASSWORD_DEFAULT);
    
    $sql="INSERT INTO `aprendiz`(`nombre`, `apellido`, `correo`, `contraseña`) VALUES ('$nombre','$apellido','$correo','$contraseña')";
    
    $verificar_correo = mysqli_query($conexion, "SELECT * FROM aprendiz WHERE correo='$correo' ");
	
	if(mysqli_num_rows($verificar_correo) > 0){
	 echo '
	    <script>
		  alert("Este correo ya está registrado, intenta con otro diferente");
		   window.location = "../style6/sign-up.html"; 
		</script>
	 ';
	 exit();
	}
	
	$verificar_usuario = mysqli_query($conexion, "SELECT * FROM aprendiz WHERE contraseña='$contraseña' ");
	
	if(mysqli_num_rows($verificar_usuario) > 0){
	 echo '
	    <script>
		   alert("Esta contraseña ya está registrado, intenta con otro diferente");
		   window.location = "../style6/sign-up.html";
		</script>
	 ';
	 exit();
	}

    $ejecutar=mysqli_query($conexion, $sql);


    if(!$ejecutar){
        echo"huvo algun error"; 
    }else{
        ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="aprovado.js"></script>
	
  <?php
include("sign-up.html");
    }