<?php
include('conexion.php');

$correo = $_POST['txtcorreo']

$queryusuario   = mysqli_query($conn,"SELECT * FROM aprendiz WHERE correo = '$correo'");
$nr             = mysqli_num_rows($queryusuario);
if ($nr == 1)
{
$mostrar        = mysqli_fetch_array($queryusuario);
$enviapass      = $mostrar['pass'];

$paracorreo        = $correo;
$titulo            = "Recuperar contraseña";
$mensaje           = $enviapass;
$tucorreo          = "From: xxxx@gmail.com";

if(mail($paracorreo,$titulo,$mensaje,$tucorreo))
{
    echo "<script> alert('Contraseña enviada');window.location= 'sing-in.html' </script>";
}else
{
    echo "<script> alert('Error');window.location= 'sing-in.html' </script>";
}
}
else
{
    echo "<script> alert('Este correo no existe');window.location= 'sing-in.html' </script>";
}
?>